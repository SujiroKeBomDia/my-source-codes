/*
function calcular() {
    let num1 = Number(document.getElementById('num1').value)
    let num2 = Number(document.getElementById("num2").value)
    let num1_placeholder = document.getElementById("num1").placeholder

    if (num1_placeholder === "Corrente (A)") {
        document.getElementById('label_resultado').innerText = `${num1 * num2}U`
    } else if (num1_placeholder === "") {}
}

function calcTensao() {
    document.getElementById("num1").placeholder = "Corrente (A)"
    document.getElementById("num2").placeholder = "Resistência (Ω)"
}
function calcCorrente() {
    document.getElementById("num1").placeholder = "Tensão (U)"
    document.getElementById("num2").placeholder = "Resistência (R)"
}
*/

let modo = "tensao"

function calcTensao() {
    modo = "tensao"
    document.getElementById("num1").placeholder = "Corrente (A)"
    document.getElementById("num2").placeholder = "Resistência (Ω)"
}

function calcCorrente() {
    modo = "corrente"
    document.getElementById("num1").placeholder = "Tensão (V)"
    document.getElementById("num2").placeholder = "Resistência (Ω)"
}

function calcResistencia() {
    modo = "resistencia"
    document.getElementById("num1").placeholder = "Tensão (V)"
    document.getElementById("num2").placeholder = "Corrente (A)"
}

function calcular() {
    let num1 = Number(document.getElementById('num1').value)
    let num2 = Number(document.getElementById('num2').value)
    let label = document.getElementById('label_resultado')

    if (modo === "tensao") {
        label.innerText = `Tensão: ${num1 * num2} V`
    }
    else if (modo === "corrente") {
        label.innerText = `Corrente: ${num1 / num2} A`
    }
    else if (modo === "resistencia") {
        label.innerText = `Resistência: ${num1 / num2} Ω`
    }
}