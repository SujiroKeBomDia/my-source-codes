function calcular() {
    let corrente = Number(document.getElementById('num1').value)
    let resistencia = Number(document.getElementById("num2").value)
    let tensao = corrente * resistencia

    document.getElementById("label_resultado").innerText = `Tensão: ${tensao}`
}
