let modo = "tensao"

function resetCampos() {
    document.getElementById("num1").style.display = "block"
    document.getElementById("num2").style.display = "block"
    document.getElementById("lista_resistores").style.display = "none"
}

function calcTensao() {
    modo = "tensao"
    resetCampos()
    document.getElementById("num1").placeholder = "Corrente (A)"
    document.getElementById("num2").placeholder = "Resistência (Ω)"
}

function calcCorrente() {
    modo = "corrente"
    resetCampos()
    document.getElementById("num1").placeholder = "Tensão (V)"
    document.getElementById("num2").placeholder = "Resistência (Ω)"
}

function calcResistencia() {
    modo = "resistencia"
    resetCampos()
    document.getElementById("num1").placeholder = "Tensão (V)"
    document.getElementById("num2").placeholder = "Corrente (A)"
}

function calcSerie() {
    modo = "serie"
    document.getElementById("num1").style.display = "none"
    document.getElementById("num2").style.display = "none"
    document.getElementById("lista_resistores").style.display = "block"
}

function calcParalelo() {
    modo = "paralelo"
    document.getElementById("num1").style.display = "none"
    document.getElementById("num2").style.display = "none"
    document.getElementById("lista_resistores").style.display = "block"
}

function calcular() {
    let num1 = Number(document.getElementById('num1').value)
    let num2 = Number(document.getElementById('num2').value)
    let label = document.getElementById('label_resultado')

    if (modo === "tensao") {
        label.innerText = `Tensão: ${num1 * num2} V (CC)`
    }
    else if (modo === "corrente") {
        label.innerText = `Corrente: ${num1 / num2} A`
    }
    else if (modo === "resistencia") {
        label.innerText = `Resistência: ${num1 / num2} Ω`
    }
    else if (modo === "serie" || modo === "paralelo") {
        let textoInput = document.getElementById('lista_resistores').value
        let arrayResistencias = textoInput.split(',').map(Number).filter(n => n > 0)

        if (arrayResistencias.length === 0) {
            label.innerText = "Digite ao menos um valor!"
            return
        }

        if (modo === "serie") {
            let total = arrayResistencias.reduce((acc, val) => acc + val, 0)
            label.innerText = `R. Total (Série): ${total.toFixed(2)} Ω`
        } 
        else if (modo === "paralelo") {
            let somaInversos = arrayResistencias.reduce((acc, val) => acc + (1 / val), 0)
            let total = 1 / somaInversos
            label.innerText = `R. Total (Paralelo): ${total.toFixed(2)} Ω`
        }
    }
}